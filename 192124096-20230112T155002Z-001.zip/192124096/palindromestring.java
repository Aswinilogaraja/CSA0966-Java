import java.util.*;
class palindromestring{
public static void main(String args[]){
int i;
Scanner sc=new Scanner(System.in);
String str=sc.nextLine();
int strlength=str.length();
for(int i=strlength;i>=0;--i)
reverse str=reverse str+charAt(i);
if(str.lowercase()equals reverse str)
{
System.out.println(str+"is a palindrome string");
}
else
{
System.out.println(str+"is not a palindrome string");
}
}
}

