import java.util.*;
class reverse{
public static void main(String args[]){
string str;
char ch;
Scanner sc=new Scanner(System.in);
System.out.println("enter the string");
Str=sc.next();
ch=sc.next();
System.out.println("reverse a string"+str+" ");
for(int j=str.length();j>0;j++);
{
System.out.print(str.char At(j-1));
}
}
}