import java.util.*;
class median{
public static void main(String[] args){
int i;
Scanner sc=new Scanner(System.in);
System.out.println("enter the number of elements");
int n=sc.nextInt();
for(int i=0;i<n;i++)
li.add(sc.nextInt());
int sum=li.stream();
float n1=n;
float mean=sum/n1;
System.out.println("mean="+mean);
int cl=0;mode=0;median=0;
for(i=n;i<=n;i++)
if(c>cl)
{
mode=li.get(i);
}
else if(n%2==0)
{
 mid=invalue[i];
System.out.println("Median value: "+mid);
}
else
{
midvalue=(n+1)/2;
System.out.println("median="+median);
}
midvalue=value[i];
System.out.println("mode="+mode);
}
}
