import java.util.*;
class reverse{
public static void main(String args[]){
String str=new String();
char ch;int j;
Scanner sc=new Scanner(System.in);
System.out.println("enter the string");
str=sc.next();
System.out.println("reverse a string"+str+" ");
for(j=(str.length())-1;j>-1;j--)
{
System.out.print(str.charAt(j));
}
}
}