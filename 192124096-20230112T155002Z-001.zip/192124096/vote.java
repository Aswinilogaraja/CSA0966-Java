import java.util.*;
class vote{
public static void main(String args[]){
int age,shrt;
Scanner sc=new Scanner(System.in);
System.out.println("enter your age");
age=sc.nextInt();
if(age>=18){
System.out.println("you can vote");
}
else
{
shrt=(18-age);
System.out.println("you cannot vote");
}
}
}