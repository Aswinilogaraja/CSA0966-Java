import java.util.*;
class interest{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
float p,t,r;
p=sc.nextInt();
t=sc.nextInt();
r=sc.nextInt();
float s1=(p*t*r)/100;
System.out.println("simple interest"+s1);
}
}
