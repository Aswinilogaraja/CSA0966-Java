import java.util.*;
class maxmin{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int[] array=new int[n];
for(int i=0;i<n;i++)
{
array[i]=sc.nextInt();
}
int max=array[0];
for(int j=0;j<array.length;j++)
{
if(array[j]>max)
max=array[j];
}
System.out.println("maximum="+max);
int min=array[0];
for(int s=0;s<array.length;s++)
{
if(array[s]<min)
min=array[s];
}
System.out.println("minimum="+min);
System.out.println("addition of max="+max);

}
}
