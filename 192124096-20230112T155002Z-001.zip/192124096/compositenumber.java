import java.util.*;
class compositenumber{
public static void main(String args[]){
int i,j;
Scanner sc=new Scanner(System.in);
System.out.println("printing composite number between a and b");
int a=sc.nextInt();
int b=sc.nextInt();
for(i=(a+1);i<b;i++)
{
int k=0;
for(j=2;j<i;j++)
{
if(i%2==0)
{
k=k+1;
}
if(k!=0)
{
System.out.println(i+"  ");
}
}
}
}
}
