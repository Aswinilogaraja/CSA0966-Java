import java.util.*;
class factorial{
public static void main(String args[]){
int i,j,pr=1;
Scanner sc=new Scanner(System.in);
System.out.println("enter the number to  find the factorial");
int n=sc.nextInt();
if(n<0)
{
System.out.println("invalid");
}
else if(n==0)
{
System.out.println("1");
}
else
{
for(i=0;i>0;i--)
{
pr=pr*i;
}
System.out.println("the answer is:"+pr);
}
System.out.println("invalid");
}
}