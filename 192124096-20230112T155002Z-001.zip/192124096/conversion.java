import java.util.*;
class conversion{
public  static void main(String[] args){
Scanner sc=new Scanner(System.in);
int decimal=sc.nextInt();
String binary=integer to binaryString;
System.out.println("BINARY is"+binary);
System.out.println("OCTAL is");
System.out.println("integer to octalstring(decimal)");
}
}