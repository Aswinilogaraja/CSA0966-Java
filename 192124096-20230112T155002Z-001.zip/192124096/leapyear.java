import java.util.*;
class leapyear{
public static void main(String[] args){
int i=0;
System.out.println("enter the year");
Scanner sc=new Scanner(System.in);
int i=sc.nextInt();
int x=integer.parseInt(r[2]);
if(x%4==0)
{
System.out.println("it is an leap year");
}
else
{
System.out.printn("it is not a leap year");
}
}
}
