import java.util.*;
public class voting{
public static void main(String args[]){
int age,shrt;
Scanner Scan=new Scanner(System.in);
System.out.println("enter your age");
age=Scan.nextln();
if(age<=18){
System.out.println("you can vote");
}
else
{
shrt=(18-age);
System.out.println("you cannot vote");
}
}
}