import java.util.*;
class star{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
int n;
n=sc.nextInt();
int a,b;
for(a=0;a<n;a++){
for(b=0;b<=a;b++){
System.out.print("*  ");
}
System.out.println();
}
}
}