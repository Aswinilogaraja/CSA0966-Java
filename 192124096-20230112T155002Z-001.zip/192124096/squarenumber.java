import java.util.*;
class squarenumber{
public static void main(String args[]){
int i;
{
int x;
Scanner sc=new Scanner(System.in);
System.out.println("first element as the number and second element as the square of the number");
int m=sc.nextInt();
int n=sc.nextInt();
x=(n-m)+1;
int k=m;
System.out.println("sqrt(m-1)");
System.out.println("the output is:");
}
}
}