import java.util.*;
class multiplicationtable{
public static void main(String args[]){
int i;
Scanner sc=new Scanner(System.in);
System.out.println("to print the multiplication table of m upto n");
System.out.println("enter the values of m and n");
int m=sc.nextInt();
int n=sc.nextInt();
for(i=1;i<=n;i++)
{
System.out.println(i+"x"+m+" = "+(m*i));
}
if(n>1)
{
System.out.println("valid");
}
else
{
System.out.println("invalid");
}
}
}
