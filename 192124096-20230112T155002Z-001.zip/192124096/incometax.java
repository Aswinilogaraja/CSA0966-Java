import java.util.*;
class incometax{
public static void main(String args[]){
int i;
Scanner sc=new Scanner(System.in);
System.out.println("enter the income");
int n=sc.nextInt();
if(n<0)
{
System.out.println("invalid");
}
else if(n==0)
{
System.out.println("no tax:0");
}
else if((0<n)&&(n<150001))
{
System.out.println("no tax:0");
}
else if((150000<n)&&(n<300001))
{
i=(n/100)*10;
System.out.println("tax:"+i);
}
else
{
i=(n/100)*30;
System.out.println("tax:"+i);
}
{
System.out.println("invalid");
}
}
}


