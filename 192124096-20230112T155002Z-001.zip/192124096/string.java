Import java.util.Scanner;
class username{
public Static void main(String[] args){
Scanner in=new Scanner(System.in);
System.out.println("enter the username");
String Str1=in.nextline();
System.out.println("reenter the username");
String Str2=in.nextline();
if(Str 1.equals (str 2)){
System.out.println("username is valid");}
else
{
System.out.println("username is not valid");}
}
}