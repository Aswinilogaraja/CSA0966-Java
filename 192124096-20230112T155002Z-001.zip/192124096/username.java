import java.util.Scanner;
class username{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("enter the username");
String s1=new String();
s1=sc.next();
System.out.println("re-enter the username");
String s2=new String();
s2=sc.next();
if(s1.equals (s2))
System.out.println("username is valid");
else
{
System.out.println("username is not valid");
}
}
}